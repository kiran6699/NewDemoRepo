package com.sathyatel.plandetails;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MicroservicePlanDetailsApplicationTests {

	@Test
	public void contextLoads() {
	}

}
