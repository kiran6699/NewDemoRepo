package com.sathyatel.frienddetails.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathyatel.frienddetails.entity.Friend;
import com.sathyatel.frienddetails.repository.FriendRepository;
import com.sathyatel.frienddetails.service.IFriendService;

@Service
public class FriendService implements IFriendService {
	@Autowired
	FriendRepository repository;

	@Override
	public String addFriendService(Friend friend) {

		System.out.println(friend.getPhoneNo());
		System.out.println(friend.getFriendNo());

		Integer count = repository.verifyFriendNo(friend.getPhoneNo(), friend.getFriendNo());
		if (count == 1) {
			return "all ready this contact no exist";
		} else
			repository.save(friend);
		return "Friend added successfully";
	}

	@Override
	public List<Long> getFriendsContactService(Long phoneNo) {
		List<Friend> friendsList = repository.findByPhoneNo(phoneNo);
		List<Long> longList = new ArrayList<Long>();
		for (Friend friend : friendsList) {
			longList.add(friend.getFriendNo());
		}

		return longList;
	}

}
