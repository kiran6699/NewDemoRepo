package com.sathyatel.customerdetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sathyatel.customerdetails.model.PlanDTO;

@Service
public class CustomerCircuitService {

	private static String FRIEND_URL = "http://FRIENDDETAILSMS/FriendDetailsApi/friends/{phoneNo}";
	private static String PLAN_URL = "http://PLANDETAILSMS/PlanDetailsApi/{planId}";

	@Autowired
	RestTemplate restTemplate;

	/*
	 * @Autowired CustFriendFegin ffegin;
	 * 
	 * @Autowired CustPlanFegin pfegin;
	 */

	//@HystrixCommand(fallbackMethod = "getFriendsFallback")
	public List<Long> getFriends(Long phoneNo) {

		/* return ffegin.getFriendsNumbers(phoneNo); */
		return restTemplate.getForObject(FRIEND_URL,List.class, phoneNo);
	}
	public PlanDTO getPlanData(String planId) {
		return restTemplate.getForObject(PLAN_URL, PlanDTO.class, planId); 
	}

	/*
	 * public Future<PlanDTO> getPlanData(String planId) { return new
	 * AsyncResult<PlanDTO>() {
	 * 
	 * @Override public PlanDTO invoke() { return pfegin.getSpecificPlan(planId);
	 * System.out.println("***********customercircuit invoke method**********");
	 * return restTemplate.getForObject(PLAN_URL, PlanDTO.class, planId); } }; }
	 * 
	 *//*
		 * public List<Long> getFriendsFallback(Long phoneNo) { return new
		 * ArrayList<Long>(); }
		 */
}
