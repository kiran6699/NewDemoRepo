package com.sathyatel.customerdetails.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sathyatel.customerdetails.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
	
	@Query(value ="select count(*) from customer_details where phone_no=? and password=?",nativeQuery=true)
	 public Integer  verifyUserLogin(Long phoneNo,String password);
	
}
