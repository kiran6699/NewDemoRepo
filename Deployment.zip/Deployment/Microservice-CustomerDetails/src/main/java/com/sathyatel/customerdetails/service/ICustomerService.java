package com.sathyatel.customerdetails.service;

import com.sathyatel.customerdetails.entity.Customer;
import com.sathyatel.customerdetails.model.CustomerDTO;
import com.sathyatel.customerdetails.model.Login;

public interface ICustomerService {
	public String registerCustomer(Customer customer);
	public boolean loginCustomer(Login login);
	public CustomerDTO getProfile(Long phoneNo);

}
